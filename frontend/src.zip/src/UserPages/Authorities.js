import React from 'react'

const Authorities = () => {
  return (
    <div>
      
    </div>
  )
}

export default Authorities
