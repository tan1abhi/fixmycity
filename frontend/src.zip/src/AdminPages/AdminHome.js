import React from 'react';

function AdminHome() {
  return <div>Welcome to the Admin Dashboard!</div>;
}

export default AdminHome;
